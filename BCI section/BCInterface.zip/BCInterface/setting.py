import os

DIR = os.path.dirname(os.path.abspath(__file__))

from BCInterface.BCInterface.