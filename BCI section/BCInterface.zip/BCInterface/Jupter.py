from BCInterface.Preprocessing.DataPrepare import DataPrepare
from sklearn.decomposition import PCA
# from Helpers import helper
from BCInterface.Helpers import helper
from BCInterface.Headset.collect import Collect
# from ..BCInterface.BCInterface.Helpers.helpers import helper
from BCInterface.Preprocessing.DataPrepare import DataPrepare
from BCInterface.Preprocessing.files_manager import Filesmanager

import matplotlib.pyplot as plt

if __name__ == '__main__':

    prepare = DataPrepare()
    data = prepare.get_dataFromFiles(['D:/Graduation Project/EEG-SSVEP-DataSet/5_S/U0000ai.csv'],concate=True)

    data = Extraxt_trials(data, 5)
    # print(data[0])

    car = helper.CAR(data[0])
    # print(car)

    filter = helper.butter_band_filter(car, 5, 40)
    # print(filter)

    freq, power = helper.welch(filter)
    # print(freq[0])
    plt.plot(freq[0],power[0])
    plt.grid()
    plt.show()