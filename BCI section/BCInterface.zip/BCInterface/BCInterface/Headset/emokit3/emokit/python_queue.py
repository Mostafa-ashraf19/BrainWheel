# -*- coding: utf-8 -*-
try:
    from queue import Queue
except:
    from Queue import Queue
