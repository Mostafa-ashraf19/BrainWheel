import Classifier
from sklearn.svm import SVC

class SVM(Classifier):

    def __init__(self,):
        self.Classifier = SVC()

    def Train(self):
        pass

    def predict(self):
        pass